<?php
session_start();
?>
<!DOCTYPE html>
<html>
    
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tela de recuperação de senha - FBR DIGITAL</title>
    <link rel="stylesheet" href="css/login1.css">
    
</head>
<body>
    
        
<div class="main-login">
    
     
       <div class="center-login">
            <div class="php-control"> 
                    <?php 
                    if(isset($_SESSION['status_cadastro'])):
                    ?>
                    <div class="sucesso">
                               
                            <p class="align">Cadastro efetuado!</p>
                            <p class="align esqueci">Faça login informando o seu usuário <br> e senha <a href="login.php">aqui</a></p>
                          </div>
                          <?php 
                          endif;
                          unset($_SESSION['status_cadastro']);
                          ?>
                          <?php 
                          if(isset($_SESSION['usuario_existe'])):
                          ?>
                        <div class="notificacao">
                              <p>O usuário escolhido já existe. <br> Informe outro e tente novamente.</p>
                          </div>
                          <?php 
                          endif;
                          unset($_SESSION['usuario_existe']);
                          ?>
                
                    <div class="card-login2">
                        <img  src="imagens/FBR_Horizontal_Cor_menor.png" alt="logo FBR"> 
                        
                        <form action="cadastrar.php" method="POST">
                            <div class="textfield"> 
                                <label for="Nome">Nome</label>
                                <input name="nome" type="text" size="40" placeholder="Seu Nome" autofocus="">
                            </div>
                            <div class="textfield"> 
                                <label for="Email">E-mail</label>
                                <input name="email" type="email" placeholder="Seu E-mail" autofocus="">
                            </div>
                            <div class="textfield"> 
                                <label for="Usuário">Usuário</label>
                                <input name="usuario" type="text" placeholder="Seu Usuário" autofocus="">
                            </div>
                            <div class="textfield">
                                <label for="senha">Senha</label>
                               <input name="senha" type="password" placeholder="Sua Senha"> <br>
                               
                            </div>
                            <button class="btn-login2" type="submit" >Cadastrar</button>                                               
                        </form>
                    </div>
                </div>
            
        </div>
         

                   
</body>

</html>